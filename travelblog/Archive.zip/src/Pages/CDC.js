import React from 'react';
import Footer from './Footer';
import NavBar from './NavBar';

const CDC = () =>{
return (
    <>
    <NavBar />
    
<div>
    <li><a href="https://wwwnc.cdc.gov/travel">CDC</a></li>
</div>


    

    <Footer />
    </>
)

}
export default  CDC;
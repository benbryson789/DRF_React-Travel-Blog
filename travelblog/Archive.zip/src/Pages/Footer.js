import React from 'react';
const Footer = () =>{
return (
    <>
    <footer class="py-3 bg-grey">
<p class="m-0 text-dark text-center ">Copyright &copy; React Central</p>
</footer>
    </>
)

}
export default  Footer;




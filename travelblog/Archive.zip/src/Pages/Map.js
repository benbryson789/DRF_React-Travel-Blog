import React from 'react';
import Footer from './Footer';
import NavBar from './NavBar';

const Map = () =>{
return (
    <>
    <NavBar />
    
    <div>

    <p><iframe title="MAP"  src="https://www.google.com/maps/d/embed?mid=1YtXI1aKBkTLC5fLcUe4wWW3VoNM&hl=en" width="640" height="480"></iframe></p>
  
  </div>

  <div>

    <p><iframe title ="MAP" src="https://www.state.gov/developer/geoPoliticalArea.json"width="640" height="480"></iframe></p>
  
  </div>

    <Footer />
    </>
)

}
export default  Map;